<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <sitemap>
        <loc>{{env('way')}}blog.xml</loc>
        <lastmod>{{  date("Y-m-d") }}T{{  date("H:i:s") }}+00:00</lastmod>
    </sitemap>
    <sitemap>
        <loc>{{env('way')}}campaign.xml</loc>
        <lastmod>{{  date("Y-m-d") }}T{{  date("H:i:s") }}+00:00</lastmod>
    </sitemap>
    <sitemap>
        <loc>{{env('way')}}cargo.xml</loc>
        <lastmod>{{  date("Y-m-d") }}T{{  date("H:i:s") }}+00:00</lastmod>
    </sitemap>
    <sitemap>
        <loc>{{env('way')}}services.xml</loc>
        <lastmod>{{  date("Y-m-d") }}T{{  date("H:i:s") }}+00:00</lastmod>
    </sitemap>
</sitemapindex>
