
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
        <url>
            <loc><?php echo e(env('way').'dasidigimiz-yukler'); ?></loc>
            <lastmod><?php echo e(date("Y-m-d")); ?>T<?php echo e(date("H:i:s")); ?>+00:00</lastmod>
            <image:image>
                <image:loc><?php echo e(env('way').\App\Models\settings::first()->logo); ?></image:loc>
                <image:title><![CDATA[<?php echo e('ucuz-yukdasima'); ?>]]></image:title>
                <image:caption><![CDATA[<?php echo e('Ucuz Yükdaşıma'); ?>]]></image:caption>
            </image:image>
        </url>
</urlset>
<?php /**PATH C:\Users\MSI Dragon\Desktop\ucuz yukdasima\Transport_website\project\resources\views/sitemap/cargo.blade.php ENDPATH**/ ?>