
<!-- mdb fraimwork - jquery include -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery-2.1.4.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/mdb.min.js')); ?>"></script>

<!-- carousel jquery include -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/slick.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>

<!-- custom jquery include -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>

<?php echo $__env->yieldContent('js'); ?>
<?php /**PATH C:\Users\MSI Dragon\Desktop\ucuz yukdasima\Transport_website\project\resources\views/layouts/script.blade.php ENDPATH**/ ?>