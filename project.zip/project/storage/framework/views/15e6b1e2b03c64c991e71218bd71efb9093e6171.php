<?php if(session('error')): ?>
    <div class="alert alert-danger">Gözlənilməyən xəta baş verdi!</div>
<?php endif; ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">Mesajınız göndərildi!Tezliklə əməkdaşlarımız sizinlə əlaqə saxlayacaqdır!</div>
<?php endif; ?>
<?php if(session('follow')): ?>
    <div class="alert alert-success">Abonə olduğunuz üçün təşəkkürlər!</div>
<?php endif; ?>
<?php /**PATH C:\Users\MSI Dragon\Desktop\ucuz yukdasima\Transport_website\project\resources\views/layouts/messages.blade.php ENDPATH**/ ?>