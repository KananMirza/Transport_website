
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <url>
            <loc><?php echo e(env('way').'blog/'.$data->slug); ?></loc>
            <lastmod><?php echo e(date("Y-m-d")); ?>T<?php echo e(date("H:i:s")); ?>+00:00</lastmod>
            <image:image>
                <image:loc><?php echo e(env('way').$data->image); ?></image:loc>
                <image:title><![CDATA[<?php echo e($data->slug); ?>]]></image:title>
                <image:caption><![CDATA[<?php echo e($data->title); ?>]]></image:caption>
            </image:image>
        </url>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</urlset>
<?php /**PATH C:\Users\MSI Dragon\Desktop\ucuz yukdasima\Transport_website\project\resources\views/sitemap/blog.blade.php ENDPATH**/ ?>