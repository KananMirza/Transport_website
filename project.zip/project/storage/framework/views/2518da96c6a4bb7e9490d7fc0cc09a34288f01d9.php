<?php $__env->startSection('title','Ucuz Yükdaşıma | Axtarış'); ?>

<?php $__env->startSection('content'); ?>


    <!-- breadcrumb-section - start
		================================================== -->
    <section id="breadcrumb-section" class="breadcrumb-section clearfix">
        <div class="overlay-white sec-ptb-100">
            <div class="container">

                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Ana səhifə</a></li>
                    <li class="breadcrumb-item active">Axtarış</li>
                </ol>

                <h2 class="breadcrumb-title">Axtarış</h2>

            </div>
        </div>
    </section>
    <!-- breadcrumb-section - end
    ================================================== -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI Dragon\Desktop\ucuz yukdasima\Transport_website\project\resources\views/search.blade.php ENDPATH**/ ?>