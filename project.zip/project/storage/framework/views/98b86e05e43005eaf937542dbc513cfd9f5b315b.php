<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <sitemap>
        <loc><?php echo e(env('way')); ?>blog.xml</loc>
        <lastmod><?php echo e(date("Y-m-d")); ?>T<?php echo e(date("H:i:s")); ?>+00:00</lastmod>
    </sitemap>
    <sitemap>
        <loc><?php echo e(env('way')); ?>campaign.xml</loc>
        <lastmod><?php echo e(date("Y-m-d")); ?>T<?php echo e(date("H:i:s")); ?>+00:00</lastmod>
    </sitemap>
    <sitemap>
        <loc><?php echo e(env('way')); ?>cargo.xml</loc>
        <lastmod><?php echo e(date("Y-m-d")); ?>T<?php echo e(date("H:i:s")); ?>+00:00</lastmod>
    </sitemap>
    <sitemap>
        <loc><?php echo e(env('way')); ?>services.xml</loc>
        <lastmod><?php echo e(date("Y-m-d")); ?>T<?php echo e(date("H:i:s")); ?>+00:00</lastmod>
    </sitemap>
</sitemapindex>
<?php /**PATH C:\Users\MSI Dragon\Desktop\ucuz yukdasima\Transport_website\project\resources\views/sitemap/sitemap.blade.php ENDPATH**/ ?>