
<!-- footer-section - start
		================================================== -->
<footer id="footer-section" class="footer-section clearfix">

    <!-- footer-top - start -->
    <div class="footer-top clearfix">
        <div class="overlay-black sec-ptb-100">
            <div class="container">
                <div class="row">

                    <!-- ftr-top-contant - start -->
                    <div class="col-lg-5 col-md-6 col-sm-12">
                        <div class="ftr-top-contant">

                            <div class="text-left">
                                <a href="<?php echo e(route('index')); ?>" class="brand-logo">
                                    <img src="<?php echo e(env('way').\App\Models\settings::first()->logo); ?>" alt="UcuzYükdaşıma Logo">
                                </a>
                            </div>

                            <p class="mb-40" style="margin-top: 20px">
                                <?php echo e(\App\Models\settings::first()->about); ?>

                            </p>

                            <ul class="social clearfix">

                                <li>
                                    <a href="<?php echo e(json_decode(\App\Models\settings::first()->social_link)[0]); ?>" class="bg-facebook waves-light">
                                        <i class="ion-social-facebook-outline"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(json_decode(\App\Models\settings::first()->social_link)[1]); ?>" class="bg-googleplus waves-light">
                                        <i class="ion-social-instagram-outline"></i>
                                    </a>
                                </li>

                            </ul>

                        </div>
                    </div>
                    <!-- ftr-top-contant - end -->

                    <!-- ftr-service-link - start -->
                    <div class="col-lg-2 col-md-6 col-sm-12">
                        <div class="ftr-service-link">

                            <h2 class="title-small mb-40">
                                Xidmətlərimiz
                            </h2>

                            <ul class="ftr-link-list ul-li-block">
                                <?php $__currentLoopData = \App\Models\services::where('status','1')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('serviceDetails',$service->slug)); ?>">
                                        <i class="ion-checkmark-circled"></i>
                                        <?php echo e($service->title); ?>

                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>

                        </div>
                    </div>
                    <!-- ftr-service-link - end -->

                    <!-- ftr-quick-link - start -->
                    <div class="col-lg-2 col-md-6 col-sm-12">
                        <div class="ftr-quick-link">

                            <h2 class="title-small mb-40">
                                Keçid
                            </h2>

                            <ul class="ftr-link-list ul-li-block">
                                <li>
                                    <a href="about.html">
                                        <i class="ion-checkmark-circled"></i>
                                        Ana səhifə
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('aboutIndex')); ?>">
                                        <i class="ion-checkmark-circled"></i>
                                        Haqqımızda
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('servicesIndex')); ?>">
                                        <i class="ion-checkmark-circled"></i>
                                        Xidmətlərimiz
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('blogIndex')); ?>">
                                        <i class="ion-checkmark-circled"></i>
                                        Bloq
                                    </a>
                                </li>

                                <li>
                                    <a href="<?php echo e(route('contactIndex')); ?>">
                                        <i class="ion-checkmark-circled"></i>
                                        Əlaqə
                                    </a>
                                </li>
                            </ul>

                        </div>
                    </div>
                    <!-- ftr-quick-link - end -->

                    <!-- ftr-location - start -->
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="ftr-location">

                            <h2 class="title-small mb-40">
                                Əlaqə
                            </h2>

                            <ul class="ftr-link-list ul-li-block">
                                <li>
                                    <p>
                                        <i class="ion-location"></i>
                                        <?php echo e(\App\Models\settings::first()->adress); ?>

                                    </p>
                                </li>
                                <li>
                                    <a href="tel: <?php echo e(json_decode(\App\Models\settings::first()->phones)[0]); ?>">
                                    <p>
                                        <i class="ion-iphone"></i>
                                        <?php echo e(json_decode(\App\Models\settings::first()->phones)[0]); ?>

                                    </p>
                                    </a>
                                </li>
                                <li>
                                    <a href="tel: <?php echo e(json_decode(\App\Models\settings::first()->phones)[1]); ?>">
                                    <p>
                                        <i class="ion-android-call"></i>
                                        <?php echo e(json_decode(\App\Models\settings::first()->phones)[1]); ?>

                                    </p>
                                    </a>
                                </li>
                                <li>
                                    <a href="tel: <?php echo e(json_decode(\App\Models\settings::first()->phones)[2]); ?>">
                                    <p>
                                        <i class="ion-android-call"></i>
                                        <?php echo e(json_decode(\App\Models\settings::first()->phones)[2]); ?>

                                    </p>
                                    </a>
                                </li>
                                <li>
                                    <a href="mailto: <?php echo e(\App\Models\settings::first()->email); ?>">
                                    <p>
                                        <i class="ion-android-mail"></i>
                                        <?php echo e(\App\Models\settings::first()->email); ?>

                                    </p>
                                    </a>
                                </li>
                            </ul>

                        </div>
                    </div>
                    <!-- ftr-location - start -->

                </div>
            </div>
        </div>
    </div>
    <!-- footer-top - end -->



    <!-- footer-bottom - start -->
    <div class="footer-bottom clearfix">
        <div class="container">
            <div class="row">

                <div class="col-lg-6 col-md-6 col-sm-12">
                    <p class="copyright">
                        © All Right Reserved.Developed by
                        <a href="https://kananmirza.com/" target="blank" class="clr-orange"><u>KananMirza</u></a>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- footer-bottom - end -->

</footer>
<!-- footer-section - end
================================================== -->
<?php /**PATH C:\Users\MSI Dragon\Desktop\ucuz yukdasima\Transport_website\project\resources\views/layouts/footer.blade.php ENDPATH**/ ?>